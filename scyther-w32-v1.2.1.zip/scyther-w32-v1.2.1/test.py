import pathlib

print(pathlib.Path(__file__)).parent.resolve()
