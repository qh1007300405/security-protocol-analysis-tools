This directory is filled by the script

`../make-mpa.py`

It takes the `.spdl` files from the `..` directory and prepares them for
multi-protocol analysis.
