#!/bin/sh

# Individual data
./combos-ikev1.sh
./combos-ikev2.sh

# And combine
./combos-ikev0.sh
